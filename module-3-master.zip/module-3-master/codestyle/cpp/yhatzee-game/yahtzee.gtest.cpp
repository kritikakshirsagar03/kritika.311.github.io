#include "yahtzee.hpp"
#include <cassert>
#include <iostream>

#include <gtest/gtest.h>

static int * ints(int a, int b, int c, int d, int e)
{
    int * r = new int[5];
    r[0] = a;
    r[1] = b;
    r[2] = c;
    r[3] = d;
    r[4] = e;
    return r;
}


TEST(Chance_scores_sum_of_all_dice, Chance) {
    /* Test 1 */
    ASSERT_EQ(15, Yahtzee().Chance(2,3,4,5,1));
    /* Test 2 */
    ASSERT_EQ(16, Yahtzee().Chance(3,3,4,5,1));
}

TEST(Yahtzee_scores_50, yahtzee) {
    /* Test 1 */
    ASSERT_EQ(50, Yahtzee().yahtzee(ints(4,4,4,4,4)));
    /* Test 2 */
    ASSERT_EQ(50, Yahtzee().yahtzee(ints(6,6,6,6,6)));
    ASSERT_EQ(0, Yahtzee().yahtzee(ints(6,6,6,6,3)));
}

TEST(Test_1s, Ones)
{
    ASSERT_EQ(1 , Yahtzee().Ones(1,2,3,4,5));
    ASSERT_EQ(2 , Yahtzee().Ones(1,2,1,4,5));
    ASSERT_EQ(0 , Yahtzee().Ones(6,2,2,4,5));
    ASSERT_EQ(4 , Yahtzee().Ones(1,2,1,1,1));
}

TEST( test_2s, Twos) 
{
    ASSERT_EQ(4 , Yahtzee().Twos(1,2,3,2,6));
    ASSERT_EQ(10 , Yahtzee().Twos(2,2,2,2,2));
}

TEST( test_threes, Threes) 
{
    ASSERT_EQ(6 , Yahtzee().Threes(1,2,3,2,3));
    ASSERT_EQ(12 , Yahtzee().Threes(2,3,3,3,3));
}

TEST( fours_test , Fours) 
{
    ASSERT_EQ(12 , (new Yahtzee(4,4,4,5,5))->Fours());
    ASSERT_EQ(8 , (new Yahtzee(4,4,5,5,5))->Fours());
    ASSERT_EQ(4 , (*new Yahtzee(4,5,5,5,5)).Fours());
}

TEST(fives, Fives) {
    ASSERT_EQ(10 , (new Yahtzee(4,4,4,5,5))->Fives());
    ASSERT_EQ(15 , Yahtzee(4,4,5,5,5).Fives());
    ASSERT_EQ(20 , Yahtzee(4,5,5,5,5).Fives());
}

TEST(sixes_test, sixes)  
{
    ASSERT_EQ(0 , Yahtzee(4,4,4,5,5).sixes());
    ASSERT_EQ(6 , Yahtzee(4,4,6,5,5).sixes());
    ASSERT_EQ(18 , Yahtzee(6,5,6,6,5).sixes());
}

TEST(one_pair, ScorePair) 
{
    ASSERT_EQ(6 , Yahtzee().ScorePair(3,4,3,5,6));
    ASSERT_EQ(10 , Yahtzee().ScorePair(5,3,3,3,5));
    ASSERT_EQ(12 , Yahtzee().ScorePair(5,3,6,6,5));
}

TEST( two_Pair, TwoPair)
{
    ASSERT_EQ(16 , Yahtzee().TwoPair(3,3,5,4,5));
    ASSERT_EQ(0 , Yahtzee().TwoPair(3,3,5,5,5));
}

TEST( three_of_a_kind, ThreeOfAKind) 
{
    ASSERT_EQ(9 , Yahtzee().ThreeOfAKind(3,3,3,4,5));
    ASSERT_EQ(15 , Yahtzee().ThreeOfAKind(5,3,5,4,5));
    ASSERT_EQ(0 , Yahtzee::ThreeOfAKind(3,3,3,3,5));
}

TEST( four_of_a_knd, FourOfAKind) 
{
    ASSERT_EQ(12 , Yahtzee::FourOfAKind(3,3,3,3,5));
    ASSERT_EQ(20 , Yahtzee::FourOfAKind(5,5,5,4,5));
    ASSERT_EQ(0  , Yahtzee::FourOfAKind(3,3,3,3,3));
}

TEST( smallStraight, SmallStraight) 
{
    ASSERT_EQ(15 , Yahtzee::SmallStraight(1,2,3,4,5));
    ASSERT_EQ(15 , Yahtzee::SmallStraight(2,3,4,5,1));
    ASSERT_EQ(0 , Yahtzee().SmallStraight(1,2,2,4,5));
}

TEST( largeStraight,LargeStraight ) 
{
    ASSERT_EQ(20 , Yahtzee::LargeStraight(6,2,3,4,5));
    ASSERT_EQ(20 , Yahtzee().LargeStraight(2,3,4,5,6));
    ASSERT_EQ(0, Yahtzee::LargeStraight(1,2,2,4,5));
}


TEST( fullHouse, FullHouse) 
{
    ASSERT_EQ(18 , Yahtzee().FullHouse(6,2,2,2,6));
    ASSERT_EQ(0 , Yahtzee().FullHouse(2,3,4,5,6));
}

int main(int argc, char **argv) {
    /* Call the Google Testing framework */
    testing::InitGoogleTest(&argc, argv);
    /* Run all the tests */
    return RUN_ALL_TESTS();
}