## Summary Stage 

### Coding Standards and Style