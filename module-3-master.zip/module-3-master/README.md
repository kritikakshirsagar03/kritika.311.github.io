# Day 2 - Module 1 - Code Refactoring

## Watch Introduction to Code Refactoring [here](https://youtu.be/7Xojr8J9Rso)

##  Purpose

Exposure to your first tasks in coding .
So taking forward our gully cricket example , you now know how to play with gears on and also know the playground , you also know team strategy but you still cant be the opening batsman you will first field and support others .Thats similar to code refactoring in corporate , you see others code and try to make it better 


## Problem this module solves for you

A code in software development company is not like college code that ends if it gives output, it has lot more. Professional code must  follow industry coding standards and style along with it being functionally right. This mindset shift of not just delivering a code that works, but also a code that follows standards and can be deployed is what this module will solve for you.

**Trivia:** Learning to refactor code(i.e. make the code industry compliant) can also be a way for you to contribute to open source. (Feel like this is not true... A person from India contributed to open source just by adding commas and formatting it right. Even adding commas at right places , needs a lot of thought and understanding of the code. )

## Goal : 
Learn to  look through already written code and fix coding style errors , documentation errors and also try to improve logic 

## What will you learn in this module?
1. Refactoring of code (coding standards and style)
1. Creating documentation for your code 

## How to get started with it?
Hear the audio session by mentor to get idea on the subject and then navigate through gitlab exactly like you learnt in module 0 and complete all stages.(Understand, Summarise(optional), Practice) 

------------------------------------------------

#### Start with the Understand Stage by going to [wiki](https://gitlab.iotiot.in/office-hours/pre-office/vit/module-3/wikis/home) and then complete the Summary and Practice Stages in issues.
